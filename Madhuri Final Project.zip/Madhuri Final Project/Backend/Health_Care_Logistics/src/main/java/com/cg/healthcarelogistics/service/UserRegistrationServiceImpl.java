package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.UserRegistrationDao;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {
	@Autowired
	UserRegistrationDao userRegistrationDao;

	@Override
	public boolean validateUserLogin(Long mobileNo, String password) {
		// TODO Auto-generated method stub
		return userRegistrationDao.validateUserLogin(mobileNo,password);
	}

	@Override
	public UserRegistration addUser(UserRegistration user) {
		// TODO Auto-generated method stub
		return userRegistrationDao.addUser(user);
	}

	@Override
	public List<UserRegistration> getAllUserDetails() {
		// TODO Auto-generated method stub
		return userRegistrationDao.getAllUserDetails();
	}

	@Override
	public String getDetailsBasedOnRole(Long mobile, String password) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getDetailsBasedOnRole(mobile, password);
	}

	@Override
	public UserRegistration getUserMobile(Long mobile) {
		// TODO Auto-generated method stub
		System.out.println("In testing "+userRegistrationDao.getUserMobile(mobile));
		return userRegistrationDao.getUserMobile(mobile);
	}

	@Override
	public Integer booking(String umail, String tmail) {
		// TODO Auto-generated method stub
		return userRegistrationDao.booking(umail, tmail);
	}

	@Override
	public List<UserRegistration> getDetails(String tmail) {
		// TODO Auto-generated method stub
		return userRegistrationDao.getDetails(tmail);
	}

	@Override
	public void delete(Long mobile) {
		// TODO Auto-generated method stub
		userRegistrationDao.delete(mobile);
	}

	
	

	

}
