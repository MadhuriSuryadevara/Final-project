package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TechnicianService {
	public Technician addTechnician(Technician managerRole);
	public List<Technician> getAllTechnician();
	public void updateTechnician(Long mobile,Integer salary,Integer experience);
	public void deleteTechnician(Long mobileNo);
	public Technician getById(Long mobileNo);
	public boolean getTechnicianDetails(Long mobile,String password);
	public List<Technician> getTechnicianByName(String name);
	
	/*public ManagerRole addTest(ManagerRole test);
	public void updateTest(Integer testId,Integer price);
	public List<ManagerRole> getAllTests();*/
}
