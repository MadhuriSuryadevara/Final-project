package com.cg.healthcarelogistics.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="users_registration")
public class UserRegistration {
	@Id
	@Indexed(name="_id")
	private Long mobileNo;
	private String userName;
	private String gender;
	private String email;
	private String technicianEmail;
	private String role;
	private String password;
	private String dob;
	private Integer totalPrice=0;
	private String status; 
	
	

	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Integer totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTechnicianEmail() {
		return technicianEmail;
	}
	public void setTechnicianEmail(String technicianEmail) {
		this.technicianEmail = technicianEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public UserRegistration() {
		
	}
	
	
	
	public UserRegistration(Long mobileNo, String userName, String gender, String email, String technicianEmail,
			String role, String password, String dob, Integer totalPrice, String status) {
		super();
		this.mobileNo = mobileNo;
		this.userName = userName;
		this.gender = gender;
		this.email = email;
		this.technicianEmail = technicianEmail;
		this.role = role;
		this.password = password;
		this.dob = dob;
		this.totalPrice = totalPrice;
		this.status = status;
	}
	@Override
	public String toString() {
		return "UserRegistration [mobileNo=" + mobileNo + ", userName=" + userName + ", gender=" + gender + ", email="
				+ email + ", technicianEmail=" + technicianEmail + ", role=" + role + ", password=" + password
				+ ", dob=" + dob + ", totalPrice=" + totalPrice + ", status=" + status + "]";
	}
	
		
	
	
	
	

}
