package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.TestService;

@RestController
@RequestMapping("/technicianrole")
@CrossOrigin(origins="http://localhost:4200")

public class TestController {
	Integer totalPrice=0;
	@Autowired
	TestService technicianRoleService;
	@PostMapping("/addtests")
	public Test addTests(@RequestBody Test testDetails) {
		System.out.println("in controller"+testDetails);
		return technicianRoleService.addTest(testDetails);
	}
	
	@PutMapping("/updatetests/{testId}/{price}")
	public void updateTests(@PathVariable("testId") Long testId,@PathVariable("price") Integer testPrice ) {
		System.out.println("in update hiiiii");
		System.out.println("In update test "+testId);
		System.out.println("In update test "+testPrice);
		technicianRoleService.updateTest(testId, testPrice);
	}
	
	@GetMapping("/getalltests")
	public List<Test> getAllTests(){
		System.out.println("in controller adding tests");
		System.out.println("from controller hiii");
		return technicianRoleService.getAllTests();
	}
		
	
		
	
	
	/*@PutMapping("/billing/{cmail}/{price}")
	public void billing(@PathVariable("cmail") String cmail,@PathVariable("price") Integer testPrice)
			{
		
		System.out.println("in billing controller"+cmail+testPrice);
		technicianRoleService.billing(cmail,testPrice);
	}*/
	
@DeleteMapping("/deletetests/{id}")
public void deleteTests(@PathVariable("id") Long id) {
	System.out.println("delete test controller"+id);
	technicianRoleService.deleteTest(id);
}
@GetMapping("/get/{cmail}/{price}")
public Integer getPrice(@PathVariable("cmail") String cmail,@PathVariable("price") Integer price) {
	System.out.println("in get price controller"+cmail+price);
	return technicianRoleService.getPrice(cmail, price);
}
@GetMapping("/setprice/{cmail}")
	public void setprice(@PathVariable("cmail") String cmail) {
		technicianRoleService.setprice(cmail);
	}
@GetMapping("/gettestbyname/{name}")
public List<Test> getTestByName(@PathVariable("name") String name){
	return technicianRoleService.getTestByName(name);
}

}
