package com.cg.healthcarelogistics.dao;

import java.util.List;

import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TechnicianDao {
	public Technician addTechnician(Technician managerRole);
	public List<Technician> getAllTechnician();
	public void updateTechnician(Long mobile,Integer salary,Integer experience);
	public void deleteTechnician(Long mobileNo);
	public boolean getTechnicianDetails(Long mobile,String password);
	//public List<UserRegistration> getBookedUsers(Long techId);
	public Technician getById(Long mobileNo);
	public List<Technician> getTechnicianByName(String name);
	//tests
	//public ManagerRole addTest(ManagerRole test);
	//public void updateTest(Integer testId,Integer price);
	//public List<ManagerRole> getAllTests();
	
	

}
