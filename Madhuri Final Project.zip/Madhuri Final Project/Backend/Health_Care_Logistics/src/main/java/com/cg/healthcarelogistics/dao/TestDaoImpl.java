package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

import ch.qos.logback.core.net.SyslogOutputStream;

@Repository
public class TestDaoImpl implements  TestDao{
	Integer totalPrice=0;
@Autowired
MongoTemplate mongoTemplate;
/*@Autowired
UserRegistrationDao userRegistrationDao;*/


//method for adding the tests to database
	@Override
	public Test addTest(Test test) {
	
		// TODO Auto-generated method stub
		System.out.println("inn dao"+test);
		return mongoTemplate.insert(test);
	}

	//method for updating the test price based on the testId
	@Override
	public void updateTest(Long testId, Integer price) {
		System.out.println("In update test dao"+testId);
		System.out.println("In update test dao "+price);
		// TODO Auto-generated method stub
		List<Test> details=mongoTemplate.findAll(Test.class);
		for(Test testDetails:details) {
			System.out.println("test id"+testDetails.getTestId());
			if(testDetails.getTestId().equals(testId)) {
				System.out.println("in dao update");
				testDetails.setTestPrice(price);
				System.out.println("printing"+testDetails.getTestPrice());
				mongoTemplate.save(testDetails);
			}
		}
		
	}

	//method for fetching all the test details
	@Override
	public List<Test> getAllTests() {
		// TODO Auto-generated method stub
		System.out.println("hey!!!");
		return mongoTemplate.findAll(Test.class);
	}
	
	


//method for deleting particular test
	@Override
	public void deleteTest(Long testId) {
		// TODO Auto-generated method stub
	List<Test> data=mongoTemplate.findAll(Test.class);
	for(Test deletetests:data) {
		if(deletetests.getTestId().equals(testId)) {
			mongoTemplate.remove(deletetests);
		}
	}
		
	}
	
	//method for updating the total price
	@Override
	public Integer getPrice(String cmail,Integer price) {
		// TODO Auto-generated method stub
		List<UserRegistration> details=mongoTemplate.findAll(UserRegistration.class);
		System.out.println("data "+details);
		
		for(UserRegistration data:details) {
			System.out.println("in for");
			if(data.getEmail().equalsIgnoreCase(cmail)) {
				System.out.println("in if"+data.getEmail());
				//data.setTotalPrice(price);
				System.out.println("in if"+data.getTotalPrice());
				totalPrice=data.getTotalPrice()+price;
				data.setTotalPrice(totalPrice);
				mongoTemplate.save(data);
				return totalPrice;
	}
		}
		return totalPrice;
		}

	// method for setting price after logout
	@Override
	public void setprice(String cmail) {
		// TODO Auto-generated method stub
		List<UserRegistration> details=mongoTemplate.findAll(UserRegistration.class);
		for(UserRegistration data:details) {
			System.out.println("in for");
			if(data.getEmail().equalsIgnoreCase(cmail)) {
				System.out.println("in if"+data.getEmail());
				//data.setTotalPrice(price);
			
				
				data.setTotalPrice(0);
				mongoTemplate.save(data);
		
	}
		}
	
	
	}

	@Override
	public List<Test> getTestByName(String name) {
		// TODO Auto-generated method stub
		List<Test> list=mongoTemplate.findAll(Test.class);
		 List<Test> list1=new ArrayList<>();
		 for(Test tech:list) {
		  if(tech.getTestName().equals(name)) {
		   list1.add(tech); 
		  }
		 }
		return list1;
	}
	
}
