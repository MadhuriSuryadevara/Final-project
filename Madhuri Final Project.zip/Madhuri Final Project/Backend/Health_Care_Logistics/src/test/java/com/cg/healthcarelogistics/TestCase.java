/**
 * 
 */
package com.cg.healthcarelogistics;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.healthcarelogistics.dto.Technician;

/**
 * @author meyarram
 *
 */
public class TestCase {

	@Test
	public void test() {
		
		Technician tech=new Technician();
		tech.setMobileNo((long) 1111111111);
		tech.setTechnicianName("teff");
		tech.setExperience(37777);
		tech.setGender("male");
		tech.setPassword("teff");
		tech.setSalary(234569);
		tech.setTechnicianDescription("general");
		tech.setTechnicianEmail("teff@gmail.com");
		assertNotNull(tech);
		
		}
	@Test
	public void test1() {
		
		Technician tech=new Technician();
		tech.setMobileNo((long) 1111111111);
		tech.setTechnicianName("teff");
		tech.setExperience(37777);
		tech.setGender("male");
		tech.setPassword("teff");
		tech.setSalary(234569);
		tech.setTechnicianDescription("general");
		tech.setTechnicianEmail("teff@gmail.com");
		
		assertNull(tech);
		}
		
		
	}


