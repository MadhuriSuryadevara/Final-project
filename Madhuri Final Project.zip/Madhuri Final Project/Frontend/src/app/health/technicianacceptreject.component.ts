import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technicianacceptreject',
  templateUrl: './technicianacceptreject.component.html',
  styleUrls: ['./technicianacceptreject.component.css']
})
export class TechnicianacceptrejectComponent implements OnInit {
  result1:any=[];
  flag:boolean=false;
  data:any=[];
  val1:any=[];
  mob:number;
  userName: string;
  acceptmessage:boolean=false;
  rejectmessage:boolean=false;
  messaging:boolean=false;
  message:any;
  dis1:any;
  constructor(private service:HealthService,private router:Router) { }
/* method for accepting booking */
acceptBooking(){
  console.log("in technician")
  
  
}
/*  method for accepting booking*/
accept(mobile){
  this.message=true;
  
  
  
   this.userName="true";
  localStorage.setItem("result", this.userName)
 this.acceptmessage=true; 
this.messaging=true;

  //localStorage.setItem("email", email)
 alert("Accepted"); 
 this.dis1=localStorage.getItem("dis");
 this.dis1=false;
 localStorage.setItem("dis2",this.dis1);

}
/* method for rejecting the booking */
reject(mobile){
  
  
   this.userName="false";
   localStorage.setItem("result", this.userName)
   this.messaging=true;
 this.rejectmessage=true;
 //localStorage.setItem("email", email)

 alert("Rejected"); 

}
Logout(){
  this.router.navigate(['/home'])
}

  ngOnInit() {
    
     console.log("getting details in technician"+this.service.getBookedUsers(this.service.technicianMail))
      return this.service.getBookedUsers(this.service.technicianMail).subscribe((result1:any)=>{
        this.val1=result1;
      })
      }
    }
    
    



