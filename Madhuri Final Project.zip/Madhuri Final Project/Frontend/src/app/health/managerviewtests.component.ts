import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerviewtests',
  templateUrl: './managerviewtests.component.html',
  styleUrls: ['./managerviewtests.component.css']
})
export class ManagerviewtestsComponent implements OnInit {
 

  
  constructor(private service:HealthService,private router:Router) { }
  data:any=[];
  result:any=[];
  show:boolean=false;
  show1:boolean=false;
  
  /* method for adding new tests */
  addTests(){
    this.router.navigate(['/managertest'])
  }

  /* method for updfating particular test based on id */
updateTests(id:any){
  console.log(id)
  this.service.currentTestId=id;
  this.show=true;
  this.router.navigate(['/updatetests'])

}
/* method for deleting particular test */
deleteTests(id:any){
  this.show1=true;
  
  console.log("in delete tests ts file"+id);
   let index=this.data.indexOf(id);
  this.data.splice(index,0);  
  window.location.reload();
    this.service.deleteTests(id).subscribe();
  
  }
  /* method for displaying alla the tests  */
  getAllTests(){
    this.service.getAllTests().subscribe(result=>{this.data=result;
      console.log("in manager delete tests"+this.data);
    })
    
  
  }
  /* method for logout */
  Logout(){
    this.router.navigate(['/logout']);
  }
  ngOnInit() {
    this.service.getAllTests().subscribe(result=>{this.data=result;
      console.log("data"+this.data.test)});
  }
}
