import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-managertechnician',
  templateUrl: './managertechnician.component.html',
  styleUrls: ['./managertechnician.component.css']
})
export class ManagertechnicianComponent implements OnInit {
result:boolean=false;
  constructor(private service:HealthService,private router:Router) { }
  model:any={};
  pwd:string;
  pass:string;

  /* Method for adding new technician */
  addTechnician(){
    this.pwd=this.model.password;
    console.log("sett pwd"+this.pwd);
    this.pass=btoa(this.pwd);
    this.model.password=this.pass;
    console.log("pwdddddd id"+this.model.password);
    this.result=true;
    this.service.addTechnician(this.model).subscribe();




  }
  /* methodfor logout */
  Logout(){
    this.router.navigate(['/logout']);
  }

  ngOnInit() {
  }

}
