import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manageroperations',
  templateUrl: './manageroperations.component.html',
  styleUrls: ['./manageroperations.component.css']
})
export class ManageroperationsComponent implements OnInit {

  constructor(private router:Router) { }
  Logout(){
    this.router.navigate(['/logout']);
  }

  ngOnInit() {
  }
  /* tests(){
    this.router.navigate(['/managerviewtests'])

  }
  technician()
  {
    this.router.navigate(['/managerviewtechnician'])

  }
 */
}
